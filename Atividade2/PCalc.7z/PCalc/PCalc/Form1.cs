﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        Double numero1, numero2, Resultado;
    
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            TxtNumero1.Clear();
            TxtNumero2.Clear();
            TxtResultado.Clear();    
        }

        private void TxtNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(TxtNumero1.Text, out numero1))
            {
                MessageBox.Show("númro 1 inválido!");
                TxtNumero1.Focus();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Resultado = numero1 + numero2;
            TxtResultado.Text = Resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não é possível dividir por este valor");
                TxtNumero2.Focus();
            }
            else
            {
                Resultado = numero1 / numero2;
                TxtResultado.Text = Resultado.ToString();
            }
              
            
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Resultado = numero1 - numero2;
            TxtResultado.Text = Resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            {
                Resultado = numero1 * numero2;
                TxtResultado.Text = Resultado.ToString();
            }
        }

        private void TxtNumero2_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(TxtNumero2.Text, out numero2))
            {
                MessageBox.Show("Número 2 inválido");
                TxtNumero2.Focus();
            }
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você realmente deseja sair", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }
    }
}
