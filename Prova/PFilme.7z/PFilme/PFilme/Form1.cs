﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            lstBoxAval.Items.Clear();
        }

        private void btnExecut_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[8, 2]; //ra Final 8
            double[] mediasFilmes = new double[8];
            string auxiliar = "";
            //são 2 colunos para notas do filme e 1 e 2, totalizando 8 linhas
            for (int filme1 = 0; filme1 < 8; filme1++)
            {
                mediasFilmes[filme1] = 0;
                for (int filme2 = 0; filme2 < 2; filme2++)
                {
                    auxiliar = (Interaction.InputBox($"Insira a nota do {filme1 + 1}° filme", "Entrada de valores"));
                    if (!double.TryParse(auxiliar, out notas[filme1, filme2]))
                    {
                        MessageBox.Show("Insira um valor válido");
                        //importante dizer que, caso dê errado, você faz um nota--, pois dessa forma, ele vai passar por outro inputbox e não vai pular o que ele falhou em pegar o dado certo.
                        filme2--;
                    }
                    else
                    {
                        mediasFilmes[filme1] += notas[filme1, filme2];
                        auxiliar += $"{filme1 + 1}º pessoa {filme1} Nota filme 1: {notas[filme1, filme2]}, Nota Filme 2: {notas[filme1, filme2]}";
                        lstBoxAval.Items.Add(auxiliar);
                    }
                        
                }
            }

        }
    }
}
