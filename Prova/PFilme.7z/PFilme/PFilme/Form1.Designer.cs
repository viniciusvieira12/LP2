﻿namespace PFilme
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstBoxAval = new System.Windows.Forms.ListBox();
            this.btnExecut = new System.Windows.Forms.Button();
            this.btnLimp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstBoxAval
            // 
            this.lstBoxAval.FormattingEnabled = true;
            this.lstBoxAval.ItemHeight = 20;
            this.lstBoxAval.Location = new System.Drawing.Point(394, 31);
            this.lstBoxAval.Name = "lstBoxAval";
            this.lstBoxAval.Size = new System.Drawing.Size(363, 384);
            this.lstBoxAval.TabIndex = 0;
            // 
            // btnExecut
            // 
            this.btnExecut.Location = new System.Drawing.Point(120, 81);
            this.btnExecut.Name = "btnExecut";
            this.btnExecut.Size = new System.Drawing.Size(134, 82);
            this.btnExecut.TabIndex = 1;
            this.btnExecut.Text = "Executar";
            this.btnExecut.UseVisualStyleBackColor = true;
            this.btnExecut.Click += new System.EventHandler(this.btnExecut_Click);
            // 
            // btnLimp
            // 
            this.btnLimp.Location = new System.Drawing.Point(120, 265);
            this.btnLimp.Name = "btnLimp";
            this.btnLimp.Size = new System.Drawing.Size(134, 96);
            this.btnLimp.TabIndex = 2;
            this.btnLimp.Text = "Limpar";
            this.btnLimp.UseVisualStyleBackColor = true;
            this.btnLimp.Click += new System.EventHandler(this.btnLimp_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLimp);
            this.Controls.Add(this.btnExecut);
            this.Controls.Add(this.lstBoxAval);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstBoxAval;
        private System.Windows.Forms.Button btnExecut;
        private System.Windows.Forms.Button btnLimp;
    }
}

