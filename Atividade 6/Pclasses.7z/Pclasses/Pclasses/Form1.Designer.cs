﻿namespace Pclasses
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.FrmMensalista = new System.Windows.Forms.Button();
            this.FrmHorista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // FrmMensalista
            // 
            this.FrmMensalista.Location = new System.Drawing.Point(158, 130);
            this.FrmMensalista.Name = "FrmMensalista";
            this.FrmMensalista.Size = new System.Drawing.Size(179, 70);
            this.FrmMensalista.TabIndex = 0;
            this.FrmMensalista.Text = "Mensalista";
            this.FrmMensalista.UseVisualStyleBackColor = true;
            this.FrmMensalista.Click += new System.EventHandler(this.FrmMensalista_Click);
            // 
            // FrmHorista
            // 
            this.FrmHorista.Location = new System.Drawing.Point(463, 130);
            this.FrmHorista.Name = "FrmHorista";
            this.FrmHorista.Size = new System.Drawing.Size(191, 70);
            this.FrmHorista.TabIndex = 1;
            this.FrmHorista.Text = "Horista";
            this.FrmHorista.UseVisualStyleBackColor = true;
            this.FrmHorista.Click += new System.EventHandler(this.FrmHorista_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.FrmHorista);
            this.Controls.Add(this.FrmMensalista);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button FrmMensalista;
        private System.Windows.Forms.Button FrmHorista;
    }
}

